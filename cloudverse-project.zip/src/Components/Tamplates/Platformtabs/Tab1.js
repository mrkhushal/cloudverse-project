import React from 'react'

export default function Tab1() {
  return (
    <div>
      tab1
    </div>
  )
}

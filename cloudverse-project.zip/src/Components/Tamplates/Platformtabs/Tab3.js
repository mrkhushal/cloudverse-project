import React from 'react'

export default function Tab3() {
  return (
    <div>
      Tab3
    </div>
  )
}

import React from 'react'

export default function Tab2() {
  return (
    <div>
      tab2
    </div>
  )
}

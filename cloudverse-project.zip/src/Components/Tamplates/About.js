import React from 'react'

export default function About() {
  return (
    <div>
      <h1>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dicta rerum modi voluptatum cumque vitae. Inventore ex amet culpa recusandae in quibusdam consectetur molestiae, cupiditate sequi numquam explicabo nostrum minima blanditiis.</h1>
    </div>
  )
}

import React from 'react'

export default function Whycloudverse() {
  return (
    <div>
      <h1>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Sapiente perspiciatis vitae dolorum rerum nesciunt odio unde commodi, iure perferendis odit corrupti illo ut maiores, nulla soluta magni, quaerat doloremque autem?</h1>
      <h1>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Sapiente perspiciatis vitae dolorum rerum nesciunt odio unde commodi, iure perferendis odit corrupti illo ut maiores, nulla soluta magni, quaerat doloremque autem?</h1>
      <h1>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Sapiente perspiciatis vitae dolorum rerum nesciunt odio unde commodi, iure perferendis odit corrupti illo ut maiores, nulla soluta magni, quaerat doloremque autem?</h1>
    </div>
  )
}
